# pokemon_data.py - Enhanced Pokémon data fetcher with caching and error handling
import requests
from functools import lru_cache
from typing import Optional
from schemas import PokemonData, PokemonBaseStats, PokemonMove, PokemonAbility, PokemonEvolution

POKEAPI_BASE_URL = "https://pokeapi.co/api/v2/"
REQUEST_TIMEOUT = 10  # seconds

@lru_cache(maxsize=100)  # Caches last 100 Pokémon requests
def get_pokemon_data(pokemon_identifier: str) -> PokemonData:
    """
    Fetch comprehensive Pokémon data from PokeAPI with caching
    Args:
        pokemon_identifier: Name or ID of the Pokémon
    Returns:
        PokemonData object with all stats
    Raises:
        HTTPError: If Pokémon not found or API issues
        ValueError: If invalid data received
    """
    try:
        # Fetch basic Pokémon data
        pokemon_json = _fetch_pokeapi_data(f"pokemon/{pokemon_identifier.lower()}")
        
        # Fetch species data for evolutions
        species_json = _fetch_pokeapi_data(pokemon_json['species']['url'])
        
        # Process data in parallel where possible
        moves = _process_moves(pokemon_json['moves'][:5])  # First 5 moves
        abilities = _process_abilities(pokemon_json['abilities'])
        evolutions = _process_evolutions(species_json)
        
        return PokemonData(
            id=pokemon_json['id'],
            name=pokemon_json['name'],
            types=[t['type']['name'] for t in pokemon_json['types']],
            abilities=abilities,
            moves=moves,
            stats=_parse_base_stats(pokemon_json['stats']),
            height=pokemon_json['height'] / 10,  # Convert to meters
            weight=pokemon_json['weight'] / 10,  # Convert to kg
            evolutions=evolutions
        )
        
    except requests.exceptions.RequestException as e:
        raise ValueError(f"Failed to fetch Pokémon data: {str(e)}") from e

def _fetch_pokeapi_data(endpoint: str) -> dict:
    """Helper to fetch data from PokeAPI with error handling"""
    url = endpoint if endpoint.startswith('http') else f"{POKEAPI_BASE_URL}{endpoint}"
    response = requests.get(url, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    return response.json()

def _process_moves(move_entries: list) -> list[PokemonMove]:
    """Process move data from API response"""
    moves = []
    for entry in move_entries:
        move_data = _fetch_pokeapi_data(entry['move']['url'])
        moves.append(PokemonMove(
            name=move_data['name'],
            power=move_data.get('power'),
            accuracy=move_data.get('accuracy'),
            type=move_data['type']['name'],
            effect=next(
                (e['effect'] for e in move_data['effect_entries'] 
                 if e['language']['name'] == 'en'),
                None
            )
        ))
    return moves

def _process_abilities(ability_entries: list) -> list[PokemonAbility]:
    """Process ability data from API response"""
    abilities = []
    for entry in ability_entries:
        ability_data = _fetch_pokeapi_data(entry['ability']['url'])
        abilities.append(PokemonAbility(
            name=ability_data['name'],
            effect=next(
                (e['effect'] for e in ability_data['effect_entries'] 
                 if e['language']['name'] == 'en'),
                None
            )
        ))
    return abilities

def _process_evolutions(species_data: dict) -> list[PokemonEvolution]:
    """Process evolution chain data (simplified)"""
    evolutions = []
    if species_data.get('evolution_chain'):
        chain_data = _fetch_pokeapi_data(species_data['evolution_chain']['url'])
        if chain_data['chain']['evolves_to']:
            evo_details = chain_data['chain']['evolves_to'][0]['evolution_details'][0]
            evolutions.append(PokemonEvolution(
                name=chain_data['chain']['evolves_to'][0]['species']['name'],
                level=evo_details.get('min_level'),
                method=evo_details.get('trigger', {}).get('name')
            ))
    return evolutions

def _parse_base_stats(stats: list) -> PokemonBaseStats:
    """Convert raw stats list to PokemonBaseStats"""
    return PokemonBaseStats(
        hp=stats[0]['base_stat'],
        attack=stats[1]['base_stat'],
        defense=stats[2]['base_stat'],
        special_attack=stats[3]['base_stat'],
        special_defense=stats[4]['base_stat'],
        speed=stats[5]['base_stat']
    )

# Clear cache when needed (e.g., when updating dependencies)
def clear_cache():
    get_pokemon_data.cache_clear()