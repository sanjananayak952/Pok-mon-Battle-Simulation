from pydantic import BaseModel
from typing import List, Dict, Optional

class PokemonBaseStats(BaseModel):
    hp: int
    attack: int
    defense: int
    special_attack: int
    special_defense: int
    speed: int

class PokemonMove(BaseModel):
    name: str
    power: Optional[int]
    accuracy: Optional[int]
    type: str
    effect: Optional[str]

class PokemonAbility(BaseModel):
    name: str
    effect: Optional[str]

class PokemonEvolution(BaseModel):
    name: str
    level: Optional[int]
    method: Optional[str]

class PokemonData(BaseModel):
    id: int
    name: str
    types: List[str]
    abilities: List[PokemonAbility]
    moves: List[PokemonMove]
    stats: PokemonBaseStats
    height: float
    weight: float
    evolutions: List[PokemonEvolution]

# Add these new classes for battle simulation
class BattleLogEntry(BaseModel):
    turn: int
    attacker: str
    defender: str
    move: str
    damage: int
    effectiveness: float
    status_effect: Optional[str]
    hp_remaining: Dict[str, int]

class BattleLog(BaseModel):
    log: List[BattleLogEntry]
    winner: str
    turns: int