# battle_simulator.py #(Handles battle logic)
from typing import List, Dict, Tuple, Optional
import random
from schemas import PokemonData, PokemonMove, BattleLog, BattleLogEntry

# Type effectiveness chart (simplified)
TYPE_EFFECTIVENESS = {
    'normal': {'rock': 0.5, 'ghost': 0},
    'fire': {'fire': 0.5, 'water': 0.5, 'grass': 2, 'ice': 2, 'bug': 2, 'rock': 0.5, 'dragon': 0.5},
    'water': {'fire': 2, 'water': 0.5, 'grass': 0.5, 'ground': 2, 'rock': 2, 'dragon': 0.5},
    'electric': {'water': 2, 'electric': 0.5, 'grass': 0.5, 'ground': 0, 'flying': 2, 'dragon': 0.5},
    'grass': {'fire': 0.5, 'water': 2, 'grass': 0.5, 'poison': 0.5, 'ground': 2, 'flying': 0.5, 'bug': 0.5, 'rock': 2, 'dragon': 0.5},
    'ice': {'water': 0.5, 'grass': 2, 'ice': 0.5, 'ground': 2, 'flying': 2, 'dragon': 2},
    'fighting': {'normal': 2, 'ice': 2, 'poison': 0.5, 'flying': 0.5, 'psychic': 0.5, 'bug': 0.5, 'rock': 2, 'ghost': 0},
    'poison': {'grass': 2, 'poison': 0.5, 'ground': 0.5, 'rock': 0.5, 'ghost': 0.5},
    'ground': {'fire': 2, 'electric': 2, 'grass': 0.5, 'poison': 2, 'flying': 0, 'bug': 0.5, 'rock': 2},
    'flying': {'electric': 0.5, 'grass': 2, 'fighting': 2, 'bug': 2, 'rock': 0.5},
    'psychic': {'fighting': 2, 'poison': 2, 'psychic': 0.5},
    'bug': {'fire': 0.5, 'grass': 2, 'fighting': 0.5, 'poison': 2, 'flying': 0.5, 'psychic': 2},
    'rock': {'fire': 2, 'ice': 2, 'fighting': 0.5, 'ground': 0.5, 'flying': 2, 'bug': 2},
    'ghost': {'normal': 0, 'psychic': 2, 'ghost': 2},
    'dragon': {'dragon': 2}
}

def calculate_damage(attacker: PokemonData, defender: PokemonData, move: PokemonMove) -> Tuple[int, float]:
    """Calculate damage based on Pokémon stats and move properties"""
    if move.power is None:
        return 0, 1  # Status moves
    
    # Calculate type effectiveness
    effectiveness = 1.0
    for defender_type in defender.types:
        effectiveness *= TYPE_EFFECTIVENESS.get(move.type, {}).get(defender_type, 1.0)
    
    # Simplified damage calculation
    attack_stat = attacker.stats.attack if move.type in ['normal', 'fighting', 'poison', 'ground', 
                                                       'flying', 'bug', 'rock', 'ghost'] else attacker.stats.special_attack
    defense_stat = defender.stats.defense if move.type in ['normal', 'fighting', 'poison', 'ground', 
                                                         'flying', 'bug', 'rock', 'ghost'] else defender.stats.special_defense
    
    damage = int((((2 * 50 / 5 + 2) * move.power * (attack_stat / defense_stat)) / 50 + 2) * effectiveness * random.uniform(0.85, 1.0))
    
    return damage, effectiveness

def apply_status_effect(pokemon: PokemonData) -> Optional[str]:
    """Randomly apply a status effect (simplified)"""
    effects = ['burn', 'paralysis', 'poison', None]
    chosen_effect = random.choice(effects)
    return chosen_effect

def simulate_battle(pokemon1: PokemonData, pokemon2: PokemonData, move_choices: Dict[str, str] = None) -> BattleLog:
    """Simulate a battle between two Pokémon"""
    log = []
    hp = {
        pokemon1.name: pokemon1.stats.hp,
        pokemon2.name: pokemon2.stats.hp
    }
    status_effects = {
        pokemon1.name: None,
        pokemon2.name: None
    }
    turn = 0
    
    while hp[pokemon1.name] > 0 and hp[pokemon2.name] > 0:
        turn += 1
        
        # Determine turn order based on speed (with possible paralysis effect)
        speed1 = pokemon1.stats.speed * (0.5 if status_effects[pokemon1.name] == 'paralysis' else 1)
        speed2 = pokemon2.stats.speed * (0.5 if status_effects[pokemon2.name] == 'paralysis' else 1)
        
        if speed1 >= speed2:
            attacker, defender = pokemon1, pokemon2
        else:
            attacker, defender = pokemon2, pokemon1
        
        # Choose move (simplified - either specified or random)
        if move_choices and attacker.name in move_choices:
            move_name = move_choices[attacker.name]
            move = next((m for m in attacker.moves if m.name == move_name), None)
            if not move:
                move = random.choice(attacker.moves)
        else:
            move = random.choice(attacker.moves)
        
        # Check if attacker is paralyzed (25% chance to not attack)
        if status_effects[attacker.name] == 'paralysis' and random.random() < 0.25:
            log_entry = BattleLogEntry(
                turn=turn,
                attacker=attacker.name,
                defender=defender.name,
                move="(paralyzed)",
                damage=0,
                effectiveness=1.0,
                status_effect=None,
                hp_remaining=hp.copy()
            )
            log.append(log_entry)
            continue
        
        # Calculate damage
        damage, effectiveness = calculate_damage(attacker, defender, move)
        hp[defender.name] = max(0, hp[defender.name] - damage)
        
        # Apply status effect (10% chance for applicable moves)
        status_effect = None
        if random.random() < 0.1 and move.effect and "status" in move.effect.lower():
            status_effect = apply_status_effect(defender)
            status_effects[defender.name] = status_effect
        
        # Apply burn/poison damage at end of turn
        if status_effects[defender.name] in ['burn', 'poison'] and hp[defender.name] > 0:
            hp[defender.name] = max(0, hp[defender.name] - int(defender.stats.hp * 0.125))
        
        log_entry = BattleLogEntry(
            turn=turn,
            attacker=attacker.name,
            defender=defender.name,
            move=move.name,
            damage=damage,
            effectiveness=effectiveness,
            status_effect=status_effect,
            hp_remaining=hp.copy()
        )
        log.append(log_entry)
    
    winner = pokemon1.name if hp[pokemon1.name] > 0 else pokemon2.name
    return BattleLog(log=log, winner=winner, turns=turn)
# In battle_simulator.py
def apply_weather_effects():
    # Implement sun/rain effects that modify damage
    pass

def check_critical_hit():
    # Add 6.25% chance for critical hits
    return random.random() < 0.0625