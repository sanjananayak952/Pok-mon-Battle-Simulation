# main.py - Enhanced MCP Server Implementation
from fastapi import FastAPI, HTTPException
from typing import Dict, Optional
from pokemon_data import get_pokemon_data, clear_cache
from schemas import PokemonData, BattleLog
from battle_simulator import simulate_battle
import uvicorn

app = FastAPI(
    title="Pokémon Battle MCP Server",
    description="An MCP-compliant server for Pokémon data and battle simulations",
    version="1.0.0"
)

# Part 1: Pokémon Data Resource
@app.get("/pokemon/{pokemon_identifier}", 
         response_model=PokemonData,
         summary="Get Pokémon data",
         responses={
             200: {"description": "Successful response with Pokémon data"},
             404: {"description": "Pokémon not found"},
             500: {"description": "Internal server error"}
         })
async def get_pokemon(pokemon_identifier: str):
    """Fetch comprehensive data for a specific Pokémon
    
    - **pokemon_identifier**: Name or ID of the Pokémon (e.g. 'pikachu' or '25')
    """
    try:
        return get_pokemon_data(pokemon_identifier)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail="Internal server error")

# Part 2: Battle Simulation Tool
@app.post("/battle/simulate",
          response_model=BattleLog,
          summary="Simulate a Pokémon battle",
          responses={
              200: {"description": "Battle simulation results"},
              400: {"description": "Invalid Pokémon specified"}
          })
async def battle_simulate(
    pokemon1: str,
    pokemon2: str,
    move_choices: Optional[Dict[str, str]] = None
):
    """Simulate a turn-based battle between two Pokémon
    
    - **pokemon1**: First Pokémon's name/ID
    - **pokemon2**: Second Pokémon's name/ID  
    - **move_choices**: Optional specific moves for each Pokémon
    """
    try:
        p1_data = get_pokemon_data(pokemon1)
        p2_data = get_pokemon_data(pokemon2)
        return simulate_battle(p1_data, p2_data, move_choices)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

# MCP Manifest
@app.get("/.well-known/mcp.json",
         include_in_schema=False)
async def get_mcp_manifest():
    """MCP manifest describing the server's capabilities"""
    return {
        "api_version": "1.0",
        "contact": {
            "email": "your@email.com",
            "docs": "http://localhost:8000/docs" 
        },
        "name": "Pokémon Battle Server",
        "description": "MCP server providing Pokémon data and battle simulation",
        "resources": {
            "pokemon": {
                "description": "Comprehensive Pokémon data including stats, types, abilities, moves, and evolutions",
                "parameters": {
                    "pokemon_identifier": {
                        "type": "string",
                        "description": "Pokémon name or ID",
                        "required": True
                    }
                },
                "returns": "PokemonData"
            }
        },
        "tools": {
            "simulate_battle": {
                "description": "Simulates a battle between two Pokémon",
                "parameters": {
                    "pokemon1": {"type": "string", "description": "First Pokémon name or ID", "required": True},
                    "pokemon2": {"type": "string", "description": "Second Pokémon name or ID", "required": True},
                    "move_choices": {
                        "type": "object",
                        "description": "Optional move choices for each Pokémon",
                        "required": False
                    }
                },
                "returns": "BattleLog"
            }
        }
    }

# Admin Endpoints
@app.post("/clear-cache", include_in_schema=False)
async def clear_pokemon_cache():
    """Clear the Pokémon data cache"""
    clear_cache()
    return {"message": "Pokémon cache cleared"}

# Run the server directly for development
if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)